package com.example.pawtopia.navigation

import android.app.Activity
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.pawtopia.screen.HomeScreen
import com.example.pawtopia.screen.WelcomeScreen

@Composable
fun PawtopiaNavHost(
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController(),
) {
    val context = LocalContext.current
    NavHost(
        navController = navController,
        startDestination = Screen.Welcome.route,
        modifier = modifier
    ) {
        composable(Screen.Welcome.route) {
            WelcomeScreen(navigateToHome = {
                navController.popBackStack()
                navController.navigate(Screen.Home.route)
            },
                onNavUp = {
                    val navUp = navController.navigateUp()
                    if (!navUp) (context as Activity).finish()
                }
            )
        }
        composable(Screen.Home.route) {
            HomeScreen()
        }
    }
}